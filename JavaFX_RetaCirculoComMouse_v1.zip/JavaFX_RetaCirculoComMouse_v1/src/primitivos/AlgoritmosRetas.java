package primitivos;

public enum AlgoritmosRetas{
	DEFAULT, EQUACAO, DDA, MIDPOINT, STROKELINE
}